import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import mongoose from 'mongoose';

// Load environment variables
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
dotenv.config({ path: path.resolve(__dirname, '../.env') });

import connectDB from '../config/db.js';
import Order, { OrderItem, FactoryCounter } from '../models/Order.js';
import Product from '../models/Product.js';
import Factory from '../models/Factory.js';
import Model from '../models/Model.js';
import Category from '../models/Category.js';

const targetSerials = ["1225FM110026", "1125JB110004"];

const findNeighbor = async (serial) => {
    // Extract the numeric counter at the end
    const match = serial.match(/^(.*?)(\d+)$/);
    if (!match) return null;

    const prefix = match[1];
    const counterStr = match[2];
    const counterLen = counterStr.length;
    const counterVal = parseInt(counterStr, 10);

    // Search for neighbors within range +/- 50
    for (let offset = 1; offset <= 50; offset++) {
        // Check previous
        const prevVal = counterVal - offset;
        const prevSerial = `${prefix}${String(prevVal).padStart(counterLen, '0')}`;
        let neighbor = await OrderItem.findOne({ serialNumber: prevSerial });
        if (neighbor) return { neighbor, offset: -offset };

        // Check next
        const nextVal = counterVal + offset;
        const nextSerial = `${prefix}${String(nextVal).padStart(counterLen, '0')}`;
        neighbor = await OrderItem.findOne({ serialNumber: nextSerial });
        if (neighbor) return { neighbor, offset: offset };
    }
    return null;
};

const getNextProductId = async () => {
    const latestProduct = await Product.findOne().sort({ createdAt: -1 });
    let lastNumber = latestProduct?.productId
        ? parseInt(latestProduct.productId.replace('PROD', ''))
        : 0;

    if (isNaN(lastNumber)) lastNumber = 0;
    return `PROD${String(lastNumber + 1).padStart(5, '0')}`;
};

const restoreProducts = async () => {
    await connectDB();
    console.log('Starting restoration process...');

    try {
        for (const serial of targetSerials) {
            console.log(`\nProcessing serial: ${serial}`);

            // 1. Check if it already exists
            const existingItem = await OrderItem.findOne({ serialNumber: serial });
            if (existingItem) {
                console.log(` - OrderItem for ${serial} already exists. Skipping creation.`);
                // We might still need to check Product creation if dispatched
            } else {
                console.log(` - Searching for data sources (neighbors)...`);
                const result = await findNeighbor(serial);

                if (!result) {
                    console.log(` ⚠️ No neighbors found for ${serial}. Cannot infer data.`);
                    continue;
                }

                const { neighbor, offset } = result;
                console.log(` - Found neighbor: ${neighbor.serialNumber} (Offset: ${offset})`);

                // 2. Check/Restore Order
                let order = await Order.findOne({ orderId: neighbor.orderId });
                if (!order) {
                    console.log(` ⚠️ Parent Order ${neighbor.orderId} is missing. Recreating basic Order structure...`);
                    // Infer Order Data from Neighbor
                    // We can't know the exact serial range of the Order easily if it's gone,
                    // but we can try to reconstruct a plausible one.
                    // Or we just insert the record if we assume validation won't block us strictly on 'range'.

                    // Actually, Order.serialNumber is required.
                    // Let's guess the range based on neighbor's serial.
                    // Assuming neighbor serial is part of the range.
                    // We'll use the neighbor serial as the base for the missing order serial range?
                    // Better: regex extract prefix and guess start/end or just use a placeholder range.
                    // But strictly, we should try to restore accurately.

                    // Let's assume standard batch of 100?
                    // But maybe safer to just create the Order record with the neighbor's data.
                    // We need a serialNumber for the Order.
                    // Let's use the neighbor's serial prefix + "RANGE-RESTORED".
                    // Or try to parse neighbor serial to get prefix.

                    const match = neighbor.serialNumber.match(/^(.*?)(\d+)$/);
                    const rangeSerial = match ? `${match[1]}RESTORED` : `RESTORED-${neighbor.orderId}`;

                    // Note: This is an approximation. If the user provided the original order logic, we could do better.

                    order = new Order({
                        orderId: neighbor.orderId,
                        serialNumber: rangeSerial, // Placeholder
                        month: neighbor.month,
                        year: neighbor.year,
                        category: neighbor.category,
                        model: neighbor.model,
                        quantity: 1, // Unknown, defaulting to safe value
                        totalUnits: 1, // Unknown
                        factory: neighbor.factory,
                        status: neighbor.status, // Match neighbor
                        orderType: neighbor.orderType,
                        unitsPerBox: neighbor.unitsPerBox,
                        isTransferredToProduct: neighbor.isTransferredToProduct
                    });

                    // Retrieve Factory, Model to populate names if needed? No, ref IDs are enough.
                    await order.save();
                    console.log(`   ✅ Recreated Order ${neighbor.orderId}`);
                }

                // 3. Create OrderItem
                // Calculate box number
                // Box number logic: box = ceil(index / unitsPerBox)
                // We typically need the start index.
                // We'll estimate boxNumber based on neighbor:
                // neighborBox = ceil(neighborIndex/units)
                // targetIndex = neighborIndex + (-offset) -> actually offset is target - neighbor?
                // Wait. calculate offset: targetVal - neighborVal.
                // If offset is positive (target > neighbor), target is ahead.
                // targetBox approx = neighborBox + floor(offset / units) ??

                // Let's use the offset derived earlier.
                // offset = target - neighbor.
                // targetBox should be roughly neighborBox + correct shift.
                // Since we don't know the exact boundary (where box increments), this is an approximation.
                // But it's better than 0.

                // Logic:
                // neighborIndex (relative to start of box) is unknown.
                // But generally boxNumber increases by 1 every 'unitsPerBox'.
                // So deltaBox = floor(offset / unitsPerBox).
                // boxNumber = neighbor.boxNumber + deltaBox.

                let boxDelta = 0;
                if (neighbor.unitsPerBox > 1) {
                    boxDelta = Math.floor(offset / neighbor.unitsPerBox);
                }
                // If items are 1 per box, offset / 1 = offset.
                // If items are 10 per box, 5 items away is still same box (0 delta).

                const newBoxNumber = Math.max(1, neighbor.boxNumber + boxDelta);

                const newOrderItem = new OrderItem({
                    orderId: neighbor.orderId,
                    serialNumber: serial,
                    month: neighbor.month,
                    year: neighbor.year,
                    category: neighbor.category,
                    model: neighbor.model,
                    factory: neighbor.factory,
                    orderType: neighbor.orderType,
                    unitsPerBox: neighbor.unitsPerBox,
                    boxNumber: newBoxNumber,
                    status: neighbor.status,
                    isTransferredToProduct: neighbor.isTransferredToProduct,
                    completedAt: neighbor.completedAt,
                    dispatchedAt: neighbor.dispatchedAt
                });

                await newOrderItem.save();
                console.log(`   ✅ Restored OrderItem for ${serial}`);
            }

            // 4. Check/Restore Product
            // Only if status is 'Dispatched' or 'Completed' (implied by user req)
            // User said: "completed on same date... and in final products as well since they are dispatched"

            // Re-fetch the item (either just created or existing) to be sure of status
            const currentItem = await OrderItem.findOne({ serialNumber: serial });

            if (currentItem && (currentItem.status === 'Dispatched' || currentItem.status === 'Completed')) {
                const existingProduct = await Product.findOne({ serialNumber: serial });
                if (!existingProduct) {
                    // Create Product
                    console.log(` - Restoring Product entry for ${serial}...`);

                    const productId = await getNextProductId();
                    const model = await Model.findById(currentItem.model);

                    // Determine price
                    const price = model?.specifications?.mrpPrice || 0;

                    const newProduct = new Product({
                        productId: productId,
                        productName: model?.name || 'Restored Product',
                        description: `Restored Product from Order ${currentItem.orderId}`,
                        serialNumber: serial,
                        month: currentItem.month,
                        year: currentItem.year,
                        category: currentItem.category,
                        model: currentItem.model,
                        quantity: 1,
                        orderType: currentItem.orderType,
                        unitsPerBox: currentItem.unitsPerBox,
                        factory: currentItem.factory,
                        orderId: currentItem.orderId,
                        boxNumber: currentItem.boxNumber,
                        unit: 'Piece',
                        price: price,
                        minStockLevel: 10,
                        status: 'Active',
                        sold: false,
                        // dispatchedAt: currentItem.dispatchedAt // Product doesn't have dispatchedAt in schema?
                        // Product schema has assignedToDistributorAt? 
                        // Checking schema: has `assignedToDistributorAt`, `saleDate`. 
                        // `Order` has `dispatchedAt`. Product is the result.
                    });

                    await newProduct.save();
                    console.log(`   ✅ Restored Product ${serial} (ID: ${productId})`);

                    // Update OrderItem flag
                    currentItem.isTransferredToProduct = true;
                    await currentItem.save();
                } else {
                    console.log(` - Product entry for ${serial} already exists.`);
                }
            }
        }

        console.log('\n✨ Restoration process completed.');
        process.exit(0);
    } catch (error) {
        console.error('❌ Error during restoration:', error);
        process.exit(1);
    }
};

restoreProducts();
