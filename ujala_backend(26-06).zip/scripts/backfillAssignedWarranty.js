import dotenv from 'dotenv';
import connectDB from '../config/db.js';
import Product from '../models/Product.js';
import Distributor from '../models/Distributor.js';
import Model from '../models/Model.js';

dotenv.config();

const pickWarrantyForDistributor = (model, distributor) => {
  if (!model || !Array.isArray(model.warranty) || model.warranty.length === 0) return null;
  const state = distributor?.state?.toLowerCase();
  const district = distributor?.district?.toLowerCase();

  const exact = model.warranty.find(w =>
    w.state?.toLowerCase() === state && w.city?.toLowerCase() === district
  );
  if (exact) return exact;

  const stateOnly = model.warranty.find(w => w.state?.toLowerCase() === state);
  if (stateOnly) return stateOnly;

  return model.warranty[0] || null;
};

const run = async () => {
  try {
    await connectDB();
    console.log('Starting backfill of assignedWarranty...');

    const products = await Product.find({ distributor: { $ne: null } }).populate('model');
    // If repository contains many products, consider batching
    console.log(`Found ${products.length} products assigned to distributors`);

    let updated = 0;
    const invalidStatusProducts = [];
    for (const product of products) {
      if (product.assignedWarranty && product.assignedWarranty.duration) continue; // already set
      if (!product.distributor) continue;

      const distributor = await Distributor.findById(product.distributor);
      if (!distributor) continue;

      const warrantyEntry = pickWarrantyForDistributor(product.model, distributor);
      if (warrantyEntry) {
        const assignedWarranty = {
          duration: warrantyEntry.duration,
          durationType: warrantyEntry.durationType,
          state: warrantyEntry.state,
          city: warrantyEntry.city
        };

        try {
          // Use direct update to avoid triggering document validation (some products may have invalid enum values)
          const res = await Product.updateOne({ _id: product._id }, { $set: { assignedWarranty } });
          if (res.modifiedCount && res.modifiedCount > 0) updated++;
        } catch (err) {
          console.error(`Failed to update product ${product._id}:`, err.message);
          // collect products with potential issues for manual inspection
          invalidStatusProducts.push({ id: product._id, status: product.status });
        }
      }
    }

    if (invalidStatusProducts.length > 0) {
      console.warn('Some products failed to update (possible invalid status values):');
      invalidStatusProducts.slice(0, 20).forEach(p => console.warn(` - ${p.id} status=${p.status}`));
      if (invalidStatusProducts.length > 20) console.warn(` ...and ${invalidStatusProducts.length - 20} more`);
    }

    console.log(`Backfill complete. Updated ${updated} products.`);
    process.exit(0);
  } catch (err) {
    console.error('Backfill error:', err);
    process.exit(1);
  }
};

run();
