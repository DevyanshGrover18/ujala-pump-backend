import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import mongoose from 'mongoose';

// Load environment variables from .env file
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
dotenv.config({ path: path.resolve(__dirname, '../.env') });

import connectDB from '../config/db.js';
import Product from '../models/Product.js';
import Order, { OrderItem } from '../models/Order.js';
import Factory from '../models/Factory.js';
import Model from '../models/Model.js';
import Category from '../models/Category.js';

const TARGET_SERIALS = ['1125JB110003', '1125JB110004'];

const analyzeAndFix = async () => {
    await connectDB();

    try {
        console.log('='.repeat(60));
        console.log('🔍 ANALYSIS: Jay Pumps Box 3 Issue');
        console.log('='.repeat(60));
        console.log(`Target Serials: ${TARGET_SERIALS.join(', ')}\n`);

        // ──────────────────────────────────────────────
        // 1. Analyze OrderItems for both serials
        // ──────────────────────────────────────────────
        console.log('── OrderItems Analysis ──');
        const orderItems = await OrderItem.find({
            serialNumber: { $in: TARGET_SERIALS },
        })
            .populate('factory')
            .populate('model')
            .populate('category');

        if (orderItems.length === 0) {
            console.log('❌ No OrderItems found for these serials.');
            process.exit(0);
        }

        for (const item of orderItems) {
            console.log(`\n  Serial: ${item.serialNumber}`);
            console.log(`    OrderItem _id : ${item._id}`);
            console.log(`    Order ID      : ${item.orderId}`);
            console.log(`    Box Number    : ${item.boxNumber}`);
            console.log(`    Order Type    : ${item.orderType}`);
            console.log(`    Units Per Box : ${item.unitsPerBox}`);
            console.log(`    Status        : ${item.status}`);
            console.log(`    Factory       : ${item.factory?.name || item.factory}`);
            console.log(`    Model         : ${item.model?.name || item.model}`);
            console.log(`    Transferred   : ${item.isTransferredToProduct}`);
        }

        // ──────────────────────────────────────────────
        // 2. Analyze Products for both serials
        // ──────────────────────────────────────────────
        console.log('\n── Products Analysis ──');
        const products = await Product.find({
            serialNumber: { $in: TARGET_SERIALS },
        })
            .populate('factory')
            .populate('model');

        if (products.length === 0) {
            console.log('  No Products found for these serials (may not be dispatched yet).');
        } else {
            for (const prod of products) {
                console.log(`\n  Serial: ${prod.serialNumber}`);
                console.log(`    Product _id   : ${prod._id}`);
                console.log(`    Product ID    : ${prod.productId}`);
                console.log(`    Box Number    : ${prod.boxNumber}`);
                console.log(`    Order Type    : ${prod.orderType}`);
                console.log(`    Units Per Box : ${prod.unitsPerBox}`);
                console.log(`    Factory       : ${prod.factory?.name || prod.factory}`);
                console.log(`    Model         : ${prod.model?.name || prod.model}`);
            }
        }

        // ──────────────────────────────────────────────
        // 3. Detect the problem
        // ──────────────────────────────────────────────
        console.log('\n' + '='.repeat(60));
        console.log('🔎 DIAGNOSIS');
        console.log('='.repeat(60));

        // Get the order details
        const orderId = orderItems[0]?.orderId;
        if (!orderId) {
            console.log('❌ Cannot determine orderId. Aborting.');
            process.exit(1);
        }

        // Get all order items for this order to see full picture
        const allOrderItems = await OrderItem.find({ orderId }).sort({ serialNumber: 1 });
        console.log(`\n  Order ${orderId} has ${allOrderItems.length} total items.`);
        console.log(`  Order Type: ${allOrderItems[0]?.orderType}`);
        console.log(`  Units Per Box: ${allOrderItems[0]?.unitsPerBox}`);

        // Check for duplicate box numbers
        const boxMap = {};
        for (const item of allOrderItems) {
            if (!boxMap[item.boxNumber]) {
                boxMap[item.boxNumber] = [];
            }
            boxMap[item.boxNumber].push(item.serialNumber);
        }

        console.log('\n  Box → Serial Mapping:');
        let issuesFound = [];
        const unitsPerBox = allOrderItems[0]?.unitsPerBox || 1;

        for (const [box, serials] of Object.entries(boxMap).sort((a, b) => Number(a[0]) - Number(b[0]))) {
            const marker = serials.length > unitsPerBox ? ' ⚠️  OVER-PACKED' : serials.length < unitsPerBox ? ' ⚠️  UNDER-PACKED' : ' ✅';
            console.log(`    Box ${box}: [${serials.join(', ')}] (${serials.length} units)${marker}`);
            if (serials.length > unitsPerBox) {
                issuesFound.push({ box: Number(box), serials, expected: unitsPerBox });
            }
        }

        // Check for missing box numbers
        const maxBox = Math.max(...Object.keys(boxMap).map(Number));
        const expectedBoxes = Math.ceil(allOrderItems.length / unitsPerBox);
        const missingBoxes = [];
        for (let i = 1; i <= expectedBoxes; i++) {
            if (!boxMap[i]) {
                missingBoxes.push(i);
            }
        }
        if (missingBoxes.length > 0) {
            console.log(`\n  ⚠️  Missing box numbers: ${missingBoxes.join(', ')}`);
        }

        if (issuesFound.length === 0 && missingBoxes.length === 0) {
            console.log('\n  ✅ No box number issues detected! Everything looks correct.');
            process.exit(0);
        }

        // ──────────────────────────────────────────────
        // 4. FIX: Recalculate correct box numbers
        // ──────────────────────────────────────────────
        console.log('\n' + '='.repeat(60));
        console.log('🔧 FIXING: Recalculating box numbers');
        console.log('='.repeat(60));

        // Sort all items by serial number to get the correct order
        const sortedItems = allOrderItems.sort((a, b) =>
            a.serialNumber.localeCompare(b.serialNumber)
        );

        let fixCount = 0;
        const changes = [];

        for (let i = 0; i < sortedItems.length; i++) {
            const item = sortedItems[i];
            const correctBoxNumber = Math.ceil((i + 1) / unitsPerBox);

            if (item.boxNumber !== correctBoxNumber) {
                changes.push({
                    serial: item.serialNumber,
                    oldBox: item.boxNumber,
                    newBox: correctBoxNumber,
                    itemId: item._id,
                });
            }
        }

        if (changes.length === 0) {
            console.log('\n  ✅ No changes needed for OrderItems.');
        } else {
            console.log(`\n  Found ${changes.length} OrderItems to fix:\n`);
            for (const change of changes) {
                console.log(`    ${change.serial}: Box ${change.oldBox} → Box ${change.newBox}`);
            }

            // Apply fixes to OrderItems
            console.log('\n  Applying fixes to OrderItems...');
            for (const change of changes) {
                await OrderItem.updateOne(
                    { _id: change.itemId },
                    { $set: { boxNumber: change.newBox } }
                );
                fixCount++;
            }
            console.log(`  ✅ Fixed ${fixCount} OrderItems.`);
        }

        // ──────────────────────────────────────────────
        // 5. FIX: Also fix Products table
        // ──────────────────────────────────────────────
        console.log('\n  Checking Products table...');
        let productFixCount = 0;

        for (const change of changes) {
            const product = await Product.findOne({ serialNumber: change.serial });
            if (product && product.boxNumber !== change.newBox) {
                console.log(`    Product ${change.serial}: Box ${product.boxNumber} → Box ${change.newBox}`);
                await Product.updateOne(
                    { serialNumber: change.serial },
                    { $set: { boxNumber: change.newBox } }
                );
                productFixCount++;
            }
        }

        if (productFixCount === 0) {
            console.log('  ✅ No Products needed fixing (or no matching products found).');
        } else {
            console.log(`  ✅ Fixed ${productFixCount} Products.`);
        }

        // ──────────────────────────────────────────────
        // 6. Verify the fix
        // ──────────────────────────────────────────────
        console.log('\n' + '='.repeat(60));
        console.log('✅ VERIFICATION');
        console.log('='.repeat(60));

        const verifyItems = await OrderItem.find({ orderId }).sort({ serialNumber: 1 });
        const verifyBoxMap = {};
        for (const item of verifyItems) {
            if (!verifyBoxMap[item.boxNumber]) {
                verifyBoxMap[item.boxNumber] = [];
            }
            verifyBoxMap[item.boxNumber].push(item.serialNumber);
        }

        console.log('\n  Updated Box → Serial Mapping:');
        let allGood = true;
        for (const [box, serials] of Object.entries(verifyBoxMap).sort((a, b) => Number(a[0]) - Number(b[0]))) {
            const marker = serials.length === unitsPerBox ? ' ✅' : ' ❌ STILL WRONG';
            console.log(`    Box ${box}: [${serials.join(', ')}] (${serials.length} units)${marker}`);
            if (serials.length !== unitsPerBox) allGood = false;
        }

        if (allGood) {
            console.log('\n  🎉 All boxes are now correctly packed!');
        } else {
            console.log('\n  ⚠️  Some boxes still have issues. Manual review needed.');
        }

        console.log('\n' + '='.repeat(60));
        console.log(`📊 SUMMARY: Fixed ${fixCount} OrderItems + ${productFixCount} Products`);
        console.log('='.repeat(60));

    } catch (error) {
        console.error('\n❌ Error:', error);
        process.exit(1);
    } finally {
        await mongoose.disconnect();
        console.log('\n🔚 Database disconnected.');
        process.exit(0);
    }
};

analyzeAndFix();
