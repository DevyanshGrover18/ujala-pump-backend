import mongoose from 'mongoose';
import dotenv from 'dotenv';
import bcrypt from 'bcryptjs';
import connectDB from '../config/db.js';
import Dealer from '../models/Dealer.js';
import User from '../models/User.js';

dotenv.config();

const fixPasswords = async () => {
  try {
    await connectDB();

    const isHash = (str) => str && str.startsWith('$2');

    // 1. Fix Dealers
    const dealers = await Dealer.find({});
    console.log(`Checking ${dealers.length} dealers...`);
    let fixedDealers = 0;
    for (const dealer of dealers) {
      if (!isHash(dealer.password)) {
        console.log(`Fixing plaintext password for dealer: ${dealer.username}`);
        const hashedPassword = await bcrypt.hash(dealer.password, 10);
        await Dealer.updateOne({ _id: dealer._id }, { password: hashedPassword });
        fixedDealers++;
      }
    }
    console.log(`✅ Fixed ${fixedDealers} dealer passwords.`);

    // 2. Fix Users (must use select('+password'))
    const users = await User.find({}).select('+password');
    console.log(`Checking ${users.length} users...`);
    let fixedUsers = 0;
    for (const user of users) {
      if (!isHash(user.password)) {
        console.log(`Fixing plaintext password for user: ${user.username} (Role: ${user.role})`);
        const hashedPassword = await bcrypt.hash(user.password, 12);
        await User.updateOne({ _id: user._id }, { password: hashedPassword });
        fixedUsers++;
      }
    }
    console.log(`✅ Fixed ${fixedUsers} user passwords.`);

    console.log('✅ Password synchronization and hashing complete.');
    process.exit(0);
  } catch (error) {
    console.error('Error:', error);
    process.exit(1);
  }
};

fixPasswords();
