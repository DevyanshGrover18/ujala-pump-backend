import mongoose from 'mongoose';
import dotenv from 'dotenv';
import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import connectDB from '../config/db.js';
import Dealer from '../models/Dealer.js';
import User from '../models/User.js';

// Load environment variables
dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const resetDealers = async () => {
  try {
    // Connect to Database
    await connectDB();

    const dataPath = path.join(__dirname, '..', 'dealers_data.json');
    console.log(`Reading dealer data from ${dataPath}...`);
    
    let dealersData;
    try {
        const fileContent = await fs.readFile(dataPath, 'utf-8');
        dealersData = JSON.parse(fileContent);
    } catch (e) {
        console.error("Could not read dealers_data.json. Make sure it exists.");
        process.exit(1);
    }

    if (!dealersData || dealersData.length === 0) {
        console.log("No dealers found in JSON. Aborting to prevent data loss.");
        process.exit(1);
    }

    console.log(`Found ${dealersData.length} dealers to restore.`);

    // 1. Delete all existing dealers
    console.log('Deleting all existing dealers...');
    await Dealer.deleteMany({});
    console.log('✅ Dealers deleted.');

    // 2. Delete all existing users with role 'dealer'
    console.log('Deleting all existing users with role "dealer"...');
    await User.deleteMany({ role: 'dealer' });
    console.log('✅ Dealer users deleted.');

    // 3. Re-create Dealers and Users
    console.log('Restoring dealers and creating users...');
    
    let successCount = 0;
    let errorCount = 0;

    for (const dealerData of dealersData) {
        try {
            // Prepare Dealer object
            // We want to preserve the _id if possible to maintain relationships
            const dealerId = dealerData._id;
            
            // Remove _id from data to avoid conflict during creation if we pass it explicitly
            // Actually, we should pass it explicitly to new Dealer()
            
            // Clean up data: remove __v, createdAt, updatedAt to let mongoose handle them or keep them?
            // User said "create same dealers", so maybe we should keep createdAt? 
            // Usually safest to let Mongoose handle timestamps unless migration requires exact history.
            // Let's keep existing timestamps if possible.
            
            const { __v, ...cleanDealerData } = dealerData;

            // Create Dealer instance
            const newDealer = new Dealer(cleanDealerData);
            // newDealer.isNew = true; // It is new
            
            // We need to save the dealer first to exist
            await newDealer.save();

            // Prepare User object
            // User schema requires: username, password, role, dealer (ref)
            const userData = {
                username: dealerData.username,
                password: dealerData.password, // Plaintext, will be hashed by User pre-save hook
                role: 'dealer',
                dealer: newDealer._id,
                isActive: true // Default
            };

            // Check if user already exists (should not, as we deleted role: dealer, but maybe username conflict with other roles?)
            const existingUser = await User.findOne({ username: userData.username });
            if (existingUser) {
                console.warn(`⚠️ User with username ${userData.username} already exists (Role: ${existingUser.role}). Skipping User creation for Dealer ${dealerData.name}.`);
            } else {
                const newUser = new User(userData);
                await newUser.save();
            }

            successCount++;
            process.stdout.write('.'); // Progress indicator
        } catch (err) {
            console.error(`
❌ Error restoring dealer ${dealerData.name}:`, err.message);
            errorCount++;
        }
    }

    console.log(`

Process complete.`);
    console.log(`Successfully restored: ${successCount}`);
    console.log(`Errors: ${errorCount}`);

    process.exit(0);
  } catch (error) {
    console.error('Fatal Error:', error);
    process.exit(1);
  }
};

resetDealers();
