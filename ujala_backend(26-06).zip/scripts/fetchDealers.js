import mongoose from 'mongoose';
import dotenv from 'dotenv';
import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import connectDB from '../config/db.js';
import Dealer from '../models/Dealer.js';

// Load environment variables
dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const fetchDealers = async () => {
  try {
    // Connect to Database
    await connectDB();

    console.log('Fetching dealers...');
    const dealers = await Dealer.find({});

    console.log(`Found ${dealers.length} dealers.`);

    // Define output path
    const outputPath = path.join(__dirname, '..', 'dealers_data.json');

    // Write to JSON file
    await fs.writeFile(outputPath, JSON.stringify(dealers, null, 2));

    console.log(`Successfully saved dealer data to ${outputPath}`);

    process.exit(0);
  } catch (error) {
    console.error('Error fetching dealers:', error);
    process.exit(1);
  }
};

fetchDealers();
