import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import mongoose from 'mongoose';

// Load environment variables from .env file
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
dotenv.config({ path: path.resolve(__dirname, '../.env') });

import connectDB from '../config/db.js';
import Product from '../models/Product.js';

const targetSerials = ["1225FM110026", "1125JB110004"];

const deleteSpecificProductsGlobal = async () => {
  await connectDB();

  try {
    console.log('Starting global deletion for target serials:', targetSerials);

    // 1. Find the specific products to get their IDs
    const productsToDelete = await Product.find({ serialNumber: { $in: targetSerials } });

    const productIds = productsToDelete.map(p => p._id);
    const productIdStrings = productIds.map(id => id.toString());

    console.log(`Found ${productsToDelete.length} products to delete directly.`);
    productsToDelete.forEach(p => {
      console.log(` - Found Product: ${p.serialNumber} (ID: ${p._id})`);
    });

    if (productsToDelete.length === 0) {
      console.log("No products found with these serial numbers. Proceeding to scan for orphaned strings anyway...");
    }

    // 2. Prepare search terms: Serials AND IDs
    const searchTerms = [...targetSerials, ...productIdStrings];
    console.log("Search terms (Serials + IDs):", searchTerms);

    // 3. Scan ALL collections
    const collections = await mongoose.connection.db.listCollections().toArray();

    for (const colInfo of collections) {
      const colName = colInfo.name;
      if (colName === 'system.indexes' || colName === 'system.views') continue;

      console.log(`Scanning collection: ${colName}...`);

      const collection = mongoose.connection.db.collection(colName);
      const cursor = collection.find({});

      const matchIds = [];

      while (await cursor.hasNext()) {
        const doc = await cursor.next();
        const docStr = JSON.stringify(doc);

        // Check if document contains ANY of the search terms
        let isMatch = false;
        for (const term of searchTerms) {
          if (docStr.includes(term)) {
            isMatch = true;
            break;
          }
        }

        if (isMatch) {
          matchIds.push(doc._id);
        }
      }

      if (matchIds.length > 0) {
        console.log(`\n⚠️  Found ${matchIds.length} matching documents in '${colName}'. Deleting...`);
        const result = await collection.deleteMany({ _id: { $in: matchIds } });
        console.log(`✅ Deleted ${result.deletedCount} documents from '${colName}'.`);
      } else {
        // console.log(`   No matches in ${colName}.`);
      }
    }

    console.log('\n✨ Global deletion process completed successfully!');

  } catch (error) {
    console.error('\n❌ Error during deletion process:', error);
    process.exit(1);
  } finally {
    console.log('\n🔚 Database operation finished.');
    process.exit(0);
  }
};

deleteSpecificProductsGlobal();