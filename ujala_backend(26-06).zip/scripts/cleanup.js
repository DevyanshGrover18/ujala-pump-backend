import mongoose from 'mongoose';
import readline from 'readline';
import dotenv from 'dotenv';
import connectDB from '../config/db.js';

dotenv.config();

// Import all models to ensure they are known to Mongoose
import Category from '../models/Category.js';
import CustomerChangeRequest from '../models/CustomerChangeRequest.js';
import Dealer from '../models/Dealer.js';
import DealerDeletionRequest from '../models/DealerDeletionRequest.js';
import DealerSubDealerProduct from '../models/DealerSubDealerProduct.js';
import Distributor from '../models/Distributor.js';
import DistributorDealerProduct from '../models/DistributorDealerProduct.js';
import DistributorRequest from '../models/DistributorRequest.js';
import Factory from '../models/Factory.js';
import Model from '../models/Model.js';
import Order from '../models/Order.js';
import PasswordResetRequest from '../models/PasswordResetRequest.js';
import Product from '../models/Product.js';
import Sale from '../models/Sale.js';
import SubDealer from '../models/SubDealer.js';
import User from '../models/User.js';
import UserRole from '../models/UserRole.js';

const collectionsToKeep = ['categories', 'models'];

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

const cleanupDatabase = async () => {
  try {
    await connectDB(); // Ensure DB connection is established

    const collections = await mongoose.connection.db.collections();
    const collectionsToDelete = [];

    console.log('The following collections will have their data deleted:');
    for (const collection of collections) {
      if (!collectionsToKeep.includes(collection.collectionName)) {
        console.log(`- ${collection.collectionName}`);
        collectionsToDelete.push(collection);
      }
    }

    if (collectionsToDelete.length === 0) {
      console.log('No collections to delete.');
      process.exit(0);
    }

    rl.question('Are you sure you want to delete all data from these collections? Type "yes" to confirm: ', async (answer) => {
      if (answer.toLowerCase() === 'yes') {
        console.log('Starting cleanup...');
        for (const collection of collectionsToDelete) {
          let result;
          if (collection.collectionName === 'users') {
            result = await collection.deleteMany({ role: { $nin: ['admin'] } });
          } else {
            result = await collection.deleteMany({});
          }
          console.log(`- Deleted ${result.deletedCount} documents from ${collection.collectionName}`);
        }
        console.log('Database cleanup complete.');
      } else {
        console.log('Cleanup aborted.');
      }
      process.exit(0);
    });

  } catch (error) {
    console.error('Error during database cleanup:', error);
    process.exit(1);
  }
};

cleanupDatabase();