import mongoose from 'mongoose';
import dotenv from 'dotenv';

dotenv.config();

const dropIndex = async () => {
    try {
        await mongoose.connect(process.env.MONGODB_URL);
        console.log('Connected to MongoDB');
        
        await mongoose.connection.db.collection('models').dropIndex('serialNumber_1');
        console.log('✅ serialNumber_1 index dropped successfully');
        
    } catch (error) {
        if (error.code === 27) {
            console.log('✅ Index not found (already dropped)');
        } else {
            console.error('❌ Error:', error.message);
        }
    } finally {
        await mongoose.connection.close();
        console.log('Connection closed');
        process.exit(0);
    }
};

dropIndex();