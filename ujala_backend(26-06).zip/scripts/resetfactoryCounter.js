import mongoose from 'mongoose';
import dotenv from 'dotenv';

dotenv.config();

const resetWebberFactoryCounter = async () => {
    try {
        await mongoose.connect(process.env.MONGODB_URL);
        console.log('Connected to MongoDB');
        
        // Find Webber factory
        const Factory = mongoose.model('Factory', new mongoose.Schema({ name: String }));
        const webberFactory = await Factory.findOne({ name: /webber/i });
        
        if (!webberFactory) {
            console.log('❌ Webber Engineers Pvt. Ltd. factory not found');
            return;
        }
        
        console.log('Found factory:', webberFactory.name, webberFactory._id);
        
        // Reset counter using FactoryCounter collection
        await mongoose.connection.db.collection('factorycounters').updateOne(
            { factoryId: webberFactory._id },
            { $set: { counter: 10000 } },
            { upsert: true }
        );
        
        console.log('✅ Webber Engineers Pvt. Ltd. factory counter reset to 10000');
        
    } catch (error) {
        console.error('❌ Error:', error.message);
    } finally {
        await mongoose.connection.close();
        console.log('Connection closed');
        process.exit(0);
    }
};

resetWebberFactoryCounter();