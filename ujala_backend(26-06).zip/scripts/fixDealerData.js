import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const fixData = async () => {
  const dataPath = path.join(__dirname, '..', 'dealers_data.json');
  console.log(`Reading ${dataPath}...`);
  
  const content = await fs.readFile(dataPath, 'utf-8');
  let dealers = JSON.parse(content);

  let modifiedCount = 0;

  for (let dealer of dealers) {
    // Fix: Mittal hardware (Password too short)
    if (dealer.name === 'Mittal hardware') {
        console.log(`Fixing Mittal hardware: Password '${dealer.password}' -> '${dealer.password}123'`);
        if (dealer.password.length < 8) {
             dealer.password = dealer.password + "12345"; // Ensure > 8
             modifiedCount++;
        }
    }

    // Fix: Garg sanitary store (Password too short)
    if (dealer.name === 'Garg sanitary store') {
        console.log(`Fixing Garg sanitary store: Password '${dealer.password}' -> '${dealer.password}123'`);
        if (dealer.password.length < 8) {
             dealer.password = dealer.password + "12345";
             modifiedCount++;
        }
    }

    // Fix: VIJAY MOTER PUMP (Username conflict 'Vijay')
    if (dealer.name === 'VIJAY MOTER PUMP') {
        if (dealer.username === 'Vijay') {
             console.log(`Fixing VIJAY MOTER PUMP: Username '${dealer.username}' -> 'Vijay_Dealer'`);
             dealer.username = 'Vijay_Dealer';
             modifiedCount++;
        }
    }

    // Fix: Vijay Enteprises (Username too short)
    if (dealer.name === 'Vijay Enteprises') {
        console.log(`Checking Vijay Enteprises username: '${dealer.username}'`);
        if (dealer.username.length < 3) {
             console.log(`Fixing Vijay Enteprises: Username '${dealer.username}' -> '${dealer.username}_ent'`);
             dealer.username = dealer.username + "_ent";
             modifiedCount++;
        }
    }
  }

  if (modifiedCount > 0) {
      await fs.writeFile(dataPath, JSON.stringify(dealers, null, 2));
      console.log(`\n✅ Saved ${modifiedCount} fixes to dealers_data.json`);
  } else {
      console.log("\nNo changes needed (or conditions not met).");
  }
};

fixData();
